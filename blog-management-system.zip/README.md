# Blog Management System (MERN)

A CRUD blog app built with React, Express, Node.js, and MongoDB. Includes create/read/update/delete, search by title/content, and category filtering.

## Requirements
- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas URI

## Setup
1. Extract this project and open its folder in a terminal.
2. Install packages: `npm install`
3. Copy `.env.example` to `.env` and update `MONGO_URI` if needed.
4. Start the app: `npm run dev`
5. Open Vite's displayed URL (usually http://localhost:5173).

The Express API runs on http://localhost:5000.

## API
- `GET /api/blogs?search=&category=` list/search/filter
- `GET /api/blogs/:id` read one
- `POST /api/blogs` create
- `PUT /api/blogs/:id` update
- `DELETE /api/blogs/:id` delete

## GitHub
Create a new repository on GitHub, then from this project folder:
```bash
git init
git add .
git commit -m "Build blog management CRUD application"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```
