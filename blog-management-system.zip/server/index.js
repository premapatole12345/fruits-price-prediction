const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();
const app = express();
app.use(cors()); app.use(express.json());
const Blog = mongoose.model('Blog', new mongoose.Schema({
  title:{type:String,required:true,trim:true}, content:{type:String,required:true},
  author:{type:String,default:'Anonymous'}, category:{type:String,default:'General'},
  createdAt:{type:Date,default:Date.now}
}));
app.get('/api/blogs', async (req,res)=>{try{
 const {search='',category=''}=req.query; const filter={};
 if(search) filter.$or=[{title:{$regex:search,$options:'i'}},{content:{$regex:search,$options:'i'}}];
 if(category) filter.category=category;
 res.json(await Blog.find(filter).sort({createdAt:-1}));
}catch(e){res.status(500).json({message:e.message});}});
app.get('/api/blogs/:id',async(req,res)=>{try{const b=await Blog.findById(req.params.id);if(!b)return res.status(404).json({message:'Blog not found'});res.json(b);}catch(e){res.status(400).json({message:e.message});}});
app.post('/api/blogs',async(req,res)=>{try{const b=await Blog.create(req.body);res.status(201).json(b);}catch(e){res.status(400).json({message:e.message});}});
app.put('/api/blogs/:id',async(req,res)=>{try{const b=await Blog.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!b)return res.status(404).json({message:'Blog not found'});res.json(b);}catch(e){res.status(400).json({message:e.message});}});
app.delete('/api/blogs/:id',async(req,res)=>{try{const b=await Blog.findByIdAndDelete(req.params.id);if(!b)return res.status(404).json({message:'Blog not found'});res.json({message:'Blog deleted'});}catch(e){res.status(400).json({message:e.message});}});
const port=process.env.PORT||5000;
mongoose.connect(process.env.MONGO_URI||'mongodb://127.0.0.1:27017/blogapp')
.then(()=>app.listen(port,()=>console.log('API running on port '+port)))
.catch(e=>{console.error('MongoDB connection failed:',e.message);process.exit(1);});